package com.week1.day1;

public class DataTypeAssignments {

	public static void main(String[] args) {
		float version = 91.0f;
		String developer = "Google";
		boolean isBeta = false;
		int releaseyear = 2008;
		char shortKey = 'C';
		
		System.out.println(version);
		System.out.println(developer);
		System.out.println(isBeta);
		System.out.println(releaseyear);
		System.out.println(shortKey);
		
	}

}
