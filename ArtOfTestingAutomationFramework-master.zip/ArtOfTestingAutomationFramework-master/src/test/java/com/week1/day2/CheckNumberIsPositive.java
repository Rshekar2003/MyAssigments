package com.week1.day2;

public class CheckNumberIsPositive {

	public static void main(String[] args) {
		//to check the number is positive
		int version = 10;
		if(version>0) {
			System.out.println("The given number is positive :" + version);
		}
		else {
			System.out.println("The given number is negative :" + version);
		}
	}

}
